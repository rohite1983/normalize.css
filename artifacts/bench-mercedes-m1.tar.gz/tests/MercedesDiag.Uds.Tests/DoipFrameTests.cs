using FluentAssertions;
using MercedesDiag.Hal.Doip;
using Xunit;

namespace MercedesDiag.Uds.Tests;

public class DoipFrameTests
{
    [Fact]
    public void WriteTo_encodes_header_correctly()
    {
        var payload = new byte[] { 0x0E, 0x80, 0x00 };
        var frame = DoipFrame.Create(DoipPayloadType.RoutingActivationRequest, payload);

        var bytes = frame.ToArray();

        bytes[0].Should().Be(0x02);
        bytes[1].Should().Be(0xFD);
        bytes[2].Should().Be(0x00);
        bytes[3].Should().Be(0x05);
        bytes[4].Should().Be(0x00);
        bytes[5].Should().Be(0x00);
        bytes[6].Should().Be(0x00);
        bytes[7].Should().Be((byte)payload.Length);
        bytes.AsSpan(8).ToArray().Should().Equal(payload);
    }

    [Fact]
    public void TryReadHeader_accepts_valid_and_rejects_inverted_mismatch()
    {
        Span<byte> good = stackalloc byte[]
        {
            0x02, 0xFD, 0x80, 0x01, 0x00, 0x00, 0x00, 0x04,
            0x0E, 0x80, 0x00, 0x01,
        };
        DoipFrame.TryReadHeader(good, out var version, out var type, out var length).Should().BeTrue();
        version.Should().Be(0x02);
        type.Should().Be(DoipPayloadType.DiagnosticMessage);
        length.Should().Be(4u);

        Span<byte> bad = stackalloc byte[] { 0x02, 0xAB, 0x80, 0x01, 0x00, 0x00, 0x00, 0x00 };
        DoipFrame.TryReadHeader(bad, out _, out _, out _).Should().BeFalse();
    }

    [Fact]
    public void DiagnosticMessage_payload_layout()
    {
        var payload = DoipPayloads.DiagnosticMessage(0x0E80, 0x0001, stackalloc byte[] { 0x22, 0xF1, 0x90 });

        payload.AsSpan(0, 2).ToArray().Should().Equal(0x0E, 0x80);
        payload.AsSpan(2, 2).ToArray().Should().Equal(0x00, 0x01);
        payload.AsSpan(4).ToArray().Should().Equal(0x22, 0xF1, 0x90);
    }

    [Fact]
    public void RoutingActivation_response_parsed_with_success_code()
    {
        Span<byte> body = stackalloc byte[]
        {
            0x0E, 0x80,
            0x00, 0x01,
            0x10,
            0x00, 0x00, 0x00, 0x00,
        };

        DoipPayloads.TryParseRoutingActivationResponse(body, out var tester, out var entity, out var code)
            .Should().BeTrue();
        tester.Should().Be(0x0E80);
        entity.Should().Be((ushort)0x0001);
        code.Should().Be(DoipRoutingActivationResponseCode.Success);
    }
}
