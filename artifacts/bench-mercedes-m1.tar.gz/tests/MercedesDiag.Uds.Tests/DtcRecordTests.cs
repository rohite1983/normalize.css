using FluentAssertions;
using Xunit;

namespace MercedesDiag.Uds.Tests;

public class DtcRecordTests
{
    [Theory]
    [InlineData(0x001234u, "P001234")]
    [InlineData(0x420011u, "C020011")]
    [InlineData(0x800012u, "B000012")]
    [InlineData(0xC000FFu, "U0000FF")]
    public void FormatCode_prefixes_correctly(uint code, string expected)
    {
        new DtcRecord(code, DtcStatus.ConfirmedDtc).FormatCode().Should().Be(expected);
    }

    [Fact]
    public void ParseByStatusMaskResponse_returns_records()
    {
        ReadOnlySpan<byte> response = stackalloc byte[]
        {
            0x59, 0x02, 0xFF,
            0x00, 0x12, 0x34, 0x08,
            0x42, 0x00, 0x11, 0x09,
        };

        var records = DtcRecordParser.ParseByStatusMaskResponse(response);

        records.Should().HaveCount(2);
        records[0].Code.Should().Be(0x001234u);
        records[0].Status.Should().Be(DtcStatus.ConfirmedDtc);
        records[0].FormatCode().Should().Be("P001234");
        records[1].FormatCode().Should().Be("C020011");
    }

    [Fact]
    public void ParseByStatusMaskResponse_handles_empty_list()
    {
        ReadOnlySpan<byte> response = stackalloc byte[] { 0x59, 0x02, 0xFF };

        DtcRecordParser.ParseByStatusMaskResponse(response).Should().BeEmpty();
    }
}
