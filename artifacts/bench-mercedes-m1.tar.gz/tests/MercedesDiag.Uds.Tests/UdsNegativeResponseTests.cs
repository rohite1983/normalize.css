using FluentAssertions;
using MercedesDiag.Transport;
using Xunit;

namespace MercedesDiag.Uds.Tests;

public class UdsNegativeResponseTests
{
    [Fact]
    public async Task Negative_response_throws_with_nrc()
    {
        var channel = new StubChannel(new byte[] { 0x7F, 0x22, (byte)UdsNrc.RequestOutOfRange });
        var client = new UdsClient(channel);

        var act = () => client.ReadDataByIdentifierAsync(0xF190, CancellationToken.None).AsTask();

        var ex = await act.Should().ThrowAsync<UdsNegativeResponseException>();
        ex.Which.Code.Should().Be(UdsNrc.RequestOutOfRange);
        ex.Which.RequestService.Should().Be(UdsServices.ReadDataByIdentifier);
    }

    [Fact]
    public async Task Positive_response_returns_payload_without_header()
    {
        var channel = new StubChannel(new byte[] { 0x62, 0xF1, 0x90, 0x57, 0x44, 0x44 });
        var client = new UdsClient(channel);

        var payload = await client.ReadDataByIdentifierAsync(0xF190, CancellationToken.None);

        payload.ToArray().Should().Equal(0x57, 0x44, 0x44);
    }

    private sealed class StubChannel : IDiagnosticChannel
    {
        private readonly byte[] _response;
        public StubChannel(byte[] response) => _response = response;

        public ValueTask<ReadOnlyMemory<byte>> RequestAsync(
            ReadOnlyMemory<byte> request,
            TimeSpan timeout,
            CancellationToken ct) =>
            ValueTask.FromResult<ReadOnlyMemory<byte>>(_response);

        public ValueTask DisposeAsync() => ValueTask.CompletedTask;
    }
}
