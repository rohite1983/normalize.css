using FluentAssertions;
using MercedesDiag.Services;
using Xunit;

namespace MercedesDiag.Uds.Tests;

public class CodingWriteSafetyTests
{
    [Fact]
    public void EnsureBackedUp_throws_when_no_backup()
    {
        var safety = new CodingWriteSafety();

        Action act = () => safety.EnsureBackedUp("EZS");

        act.Should().Throw<BackupNotTakenException>();
    }

    [Fact]
    public void EnsureBackedUp_passes_after_markup()
    {
        var safety = new CodingWriteSafety();
        safety.MarkBackedUp("EZS");

        Action act = () => safety.EnsureBackedUp("EZS");

        act.Should().NotThrow();
    }

    [Fact]
    public void Backup_tracked_per_ecu()
    {
        var safety = new CodingWriteSafety();
        safety.MarkBackedUp("EZS");

        safety.IsBackedUp("EZS").Should().BeTrue();
        safety.IsBackedUp("SAM").Should().BeFalse();
    }
}
