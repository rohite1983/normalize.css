# Bench Mercedes

Personal / workshop diagnostic and coding tool for Mercedes-Benz
vehicles. Cross-platform desktop app (Windows / macOS / Linux) built
on Avalonia + .NET 8.

> **Scope.** This is a personal tool for cars the operator owns or
> services with the owner's consent. Not a commercial product. See
> [`docs/SAFETY.md`](docs/SAFETY.md) for items that are permanently
> out of scope (anti-theft write, SCN, redistribution of proprietary
> Mercedes files).

## Layout

```
src/
  MercedesDiag.Hal/         # adapter abstraction (DoIP / PCAN / J2534)
  MercedesDiag.Transport/   # ISO-TP and DoIP channels
  MercedesDiag.Uds/         # UDS (ISO 14229) client
  MercedesDiag.Kwp/         # KWP2000 client (pre-2015 cars)
  MercedesDiag.Coding/      # coding providers (YAML / .aed)
  MercedesDiag.Services/    # session orchestration, write safety
  MercedesDiag.App/         # Avalonia UI
tests/
  MercedesDiag.Uds.Tests/
docs/
```

## Build

```
dotnet restore
dotnet build
dotnet test
dotnet run --project src/MercedesDiag.App
```

Requires the .NET 8 SDK.

## Status

**M0 scaffold.** No vehicle communication yet. Next: M1 — DoIP
transport + minimum UDS set verified against a real ECU over an
ENET cable.

See the plan (committed separately) for M1..M6 details.

## License

Private / personal use. No license is granted for redistribution.
