using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using MercedesDiag.App.ViewModels;
using MercedesDiag.App.Views;
using MercedesDiag.Services;
using Microsoft.Extensions.DependencyInjection;

namespace MercedesDiag.App;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var services = Program.Host?.Services;
            var vm = services?.GetService<MainWindowViewModel>() ?? new MainWindowViewModel();
            desktop.MainWindow = new MainWindow { DataContext = vm };
            desktop.ShutdownRequested += async (_, _) =>
            {
                if (services?.GetService<ConnectionService>() is { } cs)
                {
                    await cs.DisposeAsync();
                }
            };
        }
        base.OnFrameworkInitializationCompleted();
    }
}
