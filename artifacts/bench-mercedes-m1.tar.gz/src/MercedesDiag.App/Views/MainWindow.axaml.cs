using Avalonia.Controls;

namespace MercedesDiag.App.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
