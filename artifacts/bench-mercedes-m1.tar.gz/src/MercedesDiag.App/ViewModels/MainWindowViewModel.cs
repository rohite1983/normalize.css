using System.Collections.ObjectModel;
using System.Net;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MercedesDiag.Hal.Doip;
using MercedesDiag.Services;
using MercedesDiag.Uds;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace MercedesDiag.App.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    private readonly ConnectionService _connection;

    public MainWindowViewModel()
        : this(new ConnectionService(
            NullLogger<ConnectionService>.Instance,
            NullLogger<DiagnosticSession>.Instance))
    {
    }

    public MainWindowViewModel(ConnectionService connection)
    {
        _connection = connection;
        Ecus = new ObservableCollection<EcuItemViewModel>(
            MercedesEcuCatalog.Common.Select(e => new EcuItemViewModel(e)));
        SelectedEcu = Ecus.FirstOrDefault();
    }

    [ObservableProperty]
    private string _vehicleIp = "169.254.0.1";

    [ObservableProperty]
    private string _vehiclePort = DoipAdapter.DefaultDoipPort.ToString();

    [ObservableProperty]
    private string _testerAddressHex = "0E80";

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsDisconnected))]
    private bool _isConnected;

    public bool IsDisconnected => !IsConnected;

    [ObservableProperty]
    private string _status = "Disconnected";

    [ObservableProperty]
    private string? _vin;

    [ObservableProperty]
    private EcuItemViewModel? _selectedEcu;

    public ObservableCollection<EcuItemViewModel> Ecus { get; }

    public ObservableCollection<DtcRowViewModel> Dtcs { get; } = new();

    public string Version => typeof(MainWindowViewModel).Assembly.GetName().Version?.ToString() ?? "0.1.0";

    [RelayCommand]
    private async Task ConnectAsync(CancellationToken ct)
    {
        try
        {
            if (!IPAddress.TryParse(VehicleIp, out var ip))
            {
                Status = $"Invalid IP: {VehicleIp}";
                return;
            }
            if (SelectedEcu is null)
            {
                Status = "Select an ECU first";
                return;
            }
            var tester = Convert.ToUInt16(TesterAddressHex, 16);
            if (!int.TryParse(VehiclePort, out var port) || port is < 1 or > 65535)
            {
                Status = $"Invalid port: {VehiclePort}";
                return;
            }
            var settings = new ConnectionSettings(
                new IPEndPoint(ip, port), tester, SelectedEcu.LogicalAddress);

            Status = $"Connecting to {ip}:{port}...";
            await _connection.ConnectAsync(settings, ct);
            IsConnected = true;
            Status = $"Connected. Target 0x{SelectedEcu.LogicalAddress:X4}.";
            await ReadVehicleInfoAsync(ct);
        }
        catch (Exception ex)
        {
            IsConnected = false;
            Status = $"Connect failed: {ex.Message}";
        }
    }

    [RelayCommand]
    private async Task DisconnectAsync(CancellationToken ct)
    {
        await _connection.DisconnectAsync(ct);
        IsConnected = false;
        Vin = null;
        Dtcs.Clear();
        Status = "Disconnected";
    }

    [RelayCommand(CanExecute = nameof(IsConnected))]
    private async Task ReadDtcsAsync(CancellationToken ct)
    {
        if (_connection.Session is null) return;
        try
        {
            Status = "Reading DTCs...";
            var dtcs = await _connection.Session.ReadDtcsAsync(ct);
            Dtcs.Clear();
            foreach (var d in dtcs)
            {
                Dtcs.Add(new DtcRowViewModel(d));
            }
            Status = $"{dtcs.Count} DTC(s) read";
        }
        catch (UdsNegativeResponseException ex)
        {
            Status = $"ECU rejected DTC read: {ex.Code}";
        }
        catch (Exception ex)
        {
            Status = $"DTC read failed: {ex.Message}";
        }
    }

    [RelayCommand(CanExecute = nameof(IsConnected))]
    private async Task ClearDtcsAsync(CancellationToken ct)
    {
        if (_connection.Session is null) return;
        try
        {
            Status = "Clearing DTCs...";
            await _connection.Session.ClearDtcsAsync(ct);
            Dtcs.Clear();
            Status = "DTCs cleared";
        }
        catch (Exception ex)
        {
            Status = $"Clear failed: {ex.Message}";
        }
    }

    private async Task ReadVehicleInfoAsync(CancellationToken ct)
    {
        if (_connection.Session is null) return;
        Vin = await _connection.Session.ReadVinAsync(ct);
    }

    partial void OnIsConnectedChanged(bool value)
    {
        ReadDtcsCommand.NotifyCanExecuteChanged();
        ClearDtcsCommand.NotifyCanExecuteChanged();
    }
}

public sealed class DtcRowViewModel
{
    public DtcRowViewModel(DtcRecord record)
    {
        Code = record.FormatCode();
        Status = record.Status.ToString();
        Raw = $"0x{record.Code:X6}";
    }

    public string Code { get; }
    public string Status { get; }
    public string Raw { get; }
}
