using CommunityToolkit.Mvvm.ComponentModel;

namespace MercedesDiag.App.ViewModels;

public abstract class ViewModelBase : ObservableObject { }
