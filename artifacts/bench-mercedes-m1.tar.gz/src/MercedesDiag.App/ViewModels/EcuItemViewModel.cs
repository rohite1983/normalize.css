using MercedesDiag.Services;

namespace MercedesDiag.App.ViewModels;

public sealed class EcuItemViewModel : ViewModelBase
{
    public EcuItemViewModel(MercedesEcu ecu)
    {
        Ecu = ecu;
    }

    public MercedesEcu Ecu { get; }
    public string Display => Ecu.ToString();
    public ushort LogicalAddress => Ecu.LogicalAddress;
}
