namespace MercedesDiag.Transport;

public interface IDiagnosticChannel : IAsyncDisposable
{
    ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        TimeSpan timeout,
        CancellationToken ct);
}
