using MercedesDiag.Hal;

namespace MercedesDiag.Transport.Doip;

public sealed class DoipChannel : IDiagnosticChannel
{
    private readonly IDoipAdapter _adapter;
    private readonly ushort _sourceAddress;
    private readonly ushort _targetAddress;

    public DoipChannel(IDoipAdapter adapter, ushort sourceAddress, ushort targetAddress)
    {
        _adapter = adapter;
        _sourceAddress = sourceAddress;
        _targetAddress = targetAddress;
    }

    public ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        TimeSpan timeout,
        CancellationToken ct) =>
        _adapter.SendReceiveAsync(_sourceAddress, _targetAddress, request, timeout, ct);

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
