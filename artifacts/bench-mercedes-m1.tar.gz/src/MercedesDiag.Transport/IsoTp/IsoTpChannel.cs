using MercedesDiag.Hal;

namespace MercedesDiag.Transport.IsoTp;

public sealed class IsoTpChannel : IDiagnosticChannel
{
    private readonly ICanAdapter _adapter;
    private readonly uint _txId;
    private readonly uint _rxId;

    public IsoTpChannel(ICanAdapter adapter, uint txId, uint rxId)
    {
        _adapter = adapter;
        _txId = txId;
        _rxId = rxId;
    }

    public ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        TimeSpan timeout,
        CancellationToken ct) =>
        throw new NotImplementedException("ISO-TP (ISO 15765-2) lands in M2.");

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
