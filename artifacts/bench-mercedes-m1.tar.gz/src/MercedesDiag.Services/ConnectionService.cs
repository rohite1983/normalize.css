using System.Net;
using MercedesDiag.Hal.Doip;
using MercedesDiag.Transport;
using MercedesDiag.Transport.Doip;
using Microsoft.Extensions.Logging;

namespace MercedesDiag.Services;

public sealed record ConnectionSettings(IPEndPoint VehicleEndpoint, ushort TesterAddress, ushort TargetAddress);

public sealed class ConnectionService : IAsyncDisposable
{
    private readonly ILogger<ConnectionService> _logger;
    private readonly ILogger<DiagnosticSession> _sessionLogger;
    private DoipAdapter? _adapter;
    private DoipChannel? _channel;
    private DiagnosticSession? _session;

    public ConnectionService(
        ILogger<ConnectionService> logger,
        ILogger<DiagnosticSession> sessionLogger)
    {
        _logger = logger;
        _sessionLogger = sessionLogger;
    }

    public bool IsConnected => _session is not null;

    public DiagnosticSession? Session => _session;

    public async ValueTask ConnectAsync(ConnectionSettings settings, CancellationToken ct)
    {
        await DisconnectAsync(ct).ConfigureAwait(false);

        _logger.LogInformation("Connecting to {Endpoint} (tester 0x{Tester:X4} -> target 0x{Target:X4})",
            settings.VehicleEndpoint, settings.TesterAddress, settings.TargetAddress);

        _adapter = new DoipAdapter(settings.VehicleEndpoint, settings.TesterAddress);
        await _adapter.OpenAsync(ct).ConfigureAwait(false);

        _channel = new DoipChannel(_adapter, settings.TesterAddress, settings.TargetAddress);
        _session = new DiagnosticSession(_channel, _sessionLogger);
    }

    public async ValueTask DisconnectAsync(CancellationToken ct)
    {
        if (_session is not null) await _session.DisposeAsync().ConfigureAwait(false);
        if (_channel is not null) await _channel.DisposeAsync().ConfigureAwait(false);
        if (_adapter is not null) await _adapter.DisposeAsync().ConfigureAwait(false);
        _session = null;
        _channel = null;
        _adapter = null;
    }

    public ValueTask DisposeAsync() => DisconnectAsync(CancellationToken.None);
}
