namespace MercedesDiag.Services;

public sealed record MercedesEcu(string Name, string ShortCode, ushort LogicalAddress)
{
    public override string ToString() => $"{ShortCode} — {Name} (0x{LogicalAddress:X4})";
}

public static class MercedesEcuCatalog
{
    public static readonly IReadOnlyList<MercedesEcu> Common =
    [
        new("Central Gateway", "CGW", 0x0001),
        new("Electronic Ignition Switch", "EZS", 0x0010),
        new("Engine Control Unit", "ME", 0x0012),
        new("Transmission Control", "VGS", 0x0018),
        new("Anti-lock Braking System", "ESP", 0x0029),
        new("Instrument Cluster", "IC", 0x0050),
        new("Signal Acquisition Module (Front)", "SAM-F", 0x0060),
        new("Signal Acquisition Module (Rear)", "SAM-R", 0x0061),
        new("Airbag", "SRS", 0x0068),
        new("Head-Up Telematic unit", "HU", 0x007F),
    ];
}
