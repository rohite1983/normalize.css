namespace MercedesDiag.Services;

public sealed class BackupNotTakenException : InvalidOperationException
{
    public BackupNotTakenException(string ecuName)
        : base($"Refusing to write coding for '{ecuName}': no backup has been taken in this session.") { }
}

public sealed class CodingWriteSafety
{
    private readonly HashSet<string> _backedUp = new(StringComparer.Ordinal);

    public void MarkBackedUp(string ecuName) => _backedUp.Add(ecuName);

    public void EnsureBackedUp(string ecuName)
    {
        if (!_backedUp.Contains(ecuName))
        {
            throw new BackupNotTakenException(ecuName);
        }
    }

    public bool IsBackedUp(string ecuName) => _backedUp.Contains(ecuName);
}
