using MercedesDiag.Transport;
using MercedesDiag.Uds;
using Microsoft.Extensions.Logging;

namespace MercedesDiag.Services;

public sealed class DiagnosticSession : IAsyncDisposable
{
    private readonly ILogger<DiagnosticSession> _logger;
    private readonly UdsClient _uds;

    public DiagnosticSession(IDiagnosticChannel channel, ILogger<DiagnosticSession> logger)
    {
        _logger = logger;
        _uds = new UdsClient(channel);
    }

    public UdsClient Uds => _uds;

    public async ValueTask<string?> ReadVinAsync(CancellationToken ct)
    {
        const ushort VinDid = 0xF190;
        try
        {
            var bytes = await _uds.ReadDataByIdentifierAsync(VinDid, ct).ConfigureAwait(false);
            return System.Text.Encoding.ASCII.GetString(bytes.Span).TrimEnd('\0', ' ');
        }
        catch (UdsNegativeResponseException ex)
        {
            _logger.LogWarning("VIN read rejected: {Nrc}", ex.Code);
            return null;
        }
    }

    public async ValueTask<IReadOnlyList<DtcRecord>> ReadDtcsAsync(CancellationToken ct)
    {
        await _uds.StartSessionAsync(UdsSession.Extended, ct).ConfigureAwait(false);
        return await _uds.ReadDtcByStatusMaskAsync(statusMask: 0xFF, ct).ConfigureAwait(false);
    }

    public async ValueTask ClearDtcsAsync(CancellationToken ct)
    {
        await _uds.StartSessionAsync(UdsSession.Extended, ct).ConfigureAwait(false);
        await _uds.ClearDiagnosticInformationAsync(0xFFFFFF, ct).ConfigureAwait(false);
        _logger.LogInformation("DTCs cleared");
    }

    public ValueTask DisposeAsync() => _uds.DisposeAsync();
}
