using MercedesDiag.Transport;

namespace MercedesDiag.Kwp;

public sealed class KwpClient : IAsyncDisposable
{
    private readonly IDiagnosticChannel _channel;

    public KwpClient(IDiagnosticChannel channel)
    {
        _channel = channel;
    }

    public ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        TimeSpan timeout,
        CancellationToken ct) =>
        _channel.RequestAsync(request, timeout, ct);

    public ValueTask DisposeAsync() => _channel.DisposeAsync();
}
