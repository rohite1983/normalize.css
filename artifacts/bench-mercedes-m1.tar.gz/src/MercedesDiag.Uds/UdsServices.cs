namespace MercedesDiag.Uds;

public static class UdsServices
{
    public const byte DiagnosticSessionControl = 0x10;
    public const byte EcuReset = 0x11;
    public const byte ClearDiagnosticInformation = 0x14;
    public const byte ReadDtcInformation = 0x19;
    public const byte ReadDataByIdentifier = 0x22;
    public const byte SecurityAccess = 0x27;
    public const byte CommunicationControl = 0x28;
    public const byte WriteDataByIdentifier = 0x2E;
    public const byte RoutineControl = 0x31;
    public const byte TesterPresent = 0x3E;
    public const byte ControlDtcSetting = 0x85;

    public const byte PositiveResponseOffset = 0x40;
    public const byte NegativeResponse = 0x7F;
}

public enum UdsSession : byte
{
    Default = 0x01,
    Programming = 0x02,
    Extended = 0x03,
    SafetySystem = 0x04,
}

public enum UdsNrc : byte
{
    GeneralReject = 0x10,
    ServiceNotSupported = 0x11,
    SubFunctionNotSupported = 0x12,
    IncorrectMessageLengthOrInvalidFormat = 0x13,
    ConditionsNotCorrect = 0x22,
    RequestSequenceError = 0x24,
    RequestOutOfRange = 0x31,
    SecurityAccessDenied = 0x33,
    InvalidKey = 0x35,
    ExceededNumberOfAttempts = 0x36,
    RequiredTimeDelayNotExpired = 0x37,
    ResponsePending = 0x78,
}
