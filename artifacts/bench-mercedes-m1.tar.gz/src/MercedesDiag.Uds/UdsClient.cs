using MercedesDiag.Transport;

namespace MercedesDiag.Uds;

public sealed class UdsClient : IAsyncDisposable
{
    private readonly IDiagnosticChannel _channel;
    private readonly TimeSpan _defaultTimeout;

    public UdsClient(IDiagnosticChannel channel, TimeSpan? defaultTimeout = null)
    {
        _channel = channel;
        _defaultTimeout = defaultTimeout ?? TimeSpan.FromSeconds(2);
    }

    public async ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        CancellationToken ct)
    {
        var response = await _channel.RequestAsync(request, _defaultTimeout, ct).ConfigureAwait(false);
        ThrowIfNegative(request.Span[0], response.Span);
        return response;
    }

    public async ValueTask<UdsSession> StartSessionAsync(UdsSession session, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.DiagnosticSessionControl, (byte)session };
        await RequestAsync(req, ct).ConfigureAwait(false);
        return session;
    }

    public async ValueTask<ReadOnlyMemory<byte>> ReadDataByIdentifierAsync(ushort did, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.ReadDataByIdentifier, (byte)(did >> 8), (byte)(did & 0xFF) };
        var resp = await RequestAsync(req, ct).ConfigureAwait(false);
        return resp.Length >= 3 ? resp.Slice(3) : ReadOnlyMemory<byte>.Empty;
    }

    public async ValueTask WriteDataByIdentifierAsync(ushort did, ReadOnlyMemory<byte> data, CancellationToken ct)
    {
        var req = new byte[3 + data.Length];
        req[0] = UdsServices.WriteDataByIdentifier;
        req[1] = (byte)(did >> 8);
        req[2] = (byte)(did & 0xFF);
        data.Span.CopyTo(req.AsSpan(3));
        await RequestAsync(req, ct).ConfigureAwait(false);
    }

    public async ValueTask EcuResetAsync(byte resetType, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.EcuReset, resetType };
        await RequestAsync(req, ct).ConfigureAwait(false);
    }

    public async ValueTask ClearDiagnosticInformationAsync(uint groupOfDtc, CancellationToken ct)
    {
        var req = new byte[]
        {
            UdsServices.ClearDiagnosticInformation,
            (byte)(groupOfDtc >> 16),
            (byte)(groupOfDtc >> 8),
            (byte)(groupOfDtc & 0xFF),
        };
        await RequestAsync(req, ct).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<DtcRecord>> ReadDtcByStatusMaskAsync(byte statusMask, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.ReadDtcInformation, 0x02, statusMask };
        var resp = await RequestAsync(req, ct).ConfigureAwait(false);
        return DtcRecordParser.ParseByStatusMaskResponse(resp.Span);
    }

    public async ValueTask<ReadOnlyMemory<byte>> RequestSecuritySeedAsync(byte level, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.SecurityAccess, level };
        var resp = await RequestAsync(req, ct).ConfigureAwait(false);
        return resp.Length >= 2 ? resp.Slice(2) : ReadOnlyMemory<byte>.Empty;
    }

    public async ValueTask SendSecurityKeyAsync(byte level, ReadOnlyMemory<byte> key, CancellationToken ct)
    {
        var req = new byte[2 + key.Length];
        req[0] = UdsServices.SecurityAccess;
        req[1] = (byte)(level + 1);
        key.Span.CopyTo(req.AsSpan(2));
        await RequestAsync(req, ct).ConfigureAwait(false);
    }

    public async ValueTask<ReadOnlyMemory<byte>> RoutineControlAsync(
        byte subFunction,
        ushort routineId,
        ReadOnlyMemory<byte> routineData,
        CancellationToken ct)
    {
        var req = new byte[4 + routineData.Length];
        req[0] = UdsServices.RoutineControl;
        req[1] = subFunction;
        req[2] = (byte)(routineId >> 8);
        req[3] = (byte)(routineId & 0xFF);
        routineData.Span.CopyTo(req.AsSpan(4));
        var resp = await RequestAsync(req, ct).ConfigureAwait(false);
        return resp.Length >= 4 ? resp.Slice(4) : ReadOnlyMemory<byte>.Empty;
    }

    public async ValueTask TesterPresentAsync(CancellationToken ct)
    {
        var req = new byte[] { UdsServices.TesterPresent, 0x00 };
        await RequestAsync(req, ct).ConfigureAwait(false);
    }

    private static void ThrowIfNegative(byte requestService, ReadOnlySpan<byte> response)
    {
        if (response.Length >= 3 && response[0] == UdsServices.NegativeResponse && response[1] == requestService)
        {
            throw new UdsNegativeResponseException(requestService, (UdsNrc)response[2]);
        }
    }

    public ValueTask DisposeAsync() => _channel.DisposeAsync();
}
