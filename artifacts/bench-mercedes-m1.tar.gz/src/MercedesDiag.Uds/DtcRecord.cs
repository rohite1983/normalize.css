namespace MercedesDiag.Uds;

[Flags]
public enum DtcStatus : byte
{
    None = 0x00,
    TestFailed = 0x01,
    TestFailedThisOperationCycle = 0x02,
    PendingDtc = 0x04,
    ConfirmedDtc = 0x08,
    TestNotCompletedSinceLastClear = 0x10,
    TestFailedSinceLastClear = 0x20,
    TestNotCompletedThisOperationCycle = 0x40,
    WarningIndicatorRequested = 0x80,
}

public readonly record struct DtcRecord(uint Code, DtcStatus Status)
{
    public string FormatCode()
    {
        var highByte = (Code >> 16) & 0xFF;
        var letter = (highByte & 0xC0) switch
        {
            0x00 => 'P',
            0x40 => 'C',
            0x80 => 'B',
            _ => 'U',
        };
        var digit1 = (highByte >> 4) & 0x03;
        var digit2 = highByte & 0x0F;
        var midByte = (Code >> 8) & 0xFF;
        var lowByte = Code & 0xFF;
        return $"{letter}{digit1:X1}{digit2:X1}{midByte:X2}{lowByte:X2}";
    }

    public override string ToString() => $"{FormatCode()} [{Status}]";
}
