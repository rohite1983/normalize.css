namespace MercedesDiag.Uds;

internal static class DtcRecordParser
{
    public static IReadOnlyList<DtcRecord> ParseByStatusMaskResponse(ReadOnlySpan<byte> response)
    {
        if (response.Length < 3) return Array.Empty<DtcRecord>();

        var offset = 3;
        if (response.Length <= offset) return Array.Empty<DtcRecord>();

        var remaining = response.Length - offset;
        var count = remaining / 4;
        var list = new List<DtcRecord>(count);
        for (var i = 0; i < count; i++)
        {
            var baseIndex = offset + i * 4;
            uint code = ((uint)response[baseIndex] << 16)
                      | ((uint)response[baseIndex + 1] << 8)
                      | response[baseIndex + 2];
            var status = (DtcStatus)response[baseIndex + 3];
            list.Add(new DtcRecord(code, status));
        }
        return list;
    }
}
