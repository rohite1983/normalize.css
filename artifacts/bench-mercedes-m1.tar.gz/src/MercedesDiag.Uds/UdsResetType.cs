namespace MercedesDiag.Uds;

public enum UdsResetType : byte
{
    HardReset = 0x01,
    KeyOffOnReset = 0x02,
    SoftReset = 0x03,
    EnableRapidPowerShutdown = 0x04,
    DisableRapidPowerShutdown = 0x05,
}
