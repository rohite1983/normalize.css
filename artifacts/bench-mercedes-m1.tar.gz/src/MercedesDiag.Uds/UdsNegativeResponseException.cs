namespace MercedesDiag.Uds;

public sealed class UdsNegativeResponseException : Exception
{
    public UdsNegativeResponseException(byte requestService, UdsNrc code)
        : base($"UDS negative response: service=0x{requestService:X2} nrc=0x{(byte)code:X2} ({code})")
    {
        RequestService = requestService;
        Code = code;
    }

    public byte RequestService { get; }
    public UdsNrc Code { get; }
}
