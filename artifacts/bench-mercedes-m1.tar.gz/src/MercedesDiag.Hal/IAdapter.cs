namespace MercedesDiag.Hal;

public enum AdapterKind
{
    DoipEnet,
    Pcan,
    J2534,
    SocketCan,
    SerialElm,
}

public sealed record AdapterInfo(string Id, string DisplayName, AdapterKind Kind);

public interface IAdapter : IAsyncDisposable
{
    AdapterInfo Info { get; }

    bool IsOpen { get; }

    ValueTask OpenAsync(CancellationToken ct);

    ValueTask CloseAsync(CancellationToken ct);
}

public interface IAdapterDiscovery
{
    AdapterKind Kind { get; }

    IAsyncEnumerable<AdapterInfo> EnumerateAsync(CancellationToken ct);

    ValueTask<IAdapter> OpenAsync(AdapterInfo info, CancellationToken ct);
}
