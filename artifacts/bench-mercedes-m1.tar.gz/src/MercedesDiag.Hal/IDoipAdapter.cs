using System.Net;

namespace MercedesDiag.Hal;

public interface IDoipAdapter : IAdapter
{
    IPEndPoint VehicleEndpoint { get; }

    ValueTask<ReadOnlyMemory<byte>> SendReceiveAsync(
        ushort sourceAddress,
        ushort targetAddress,
        ReadOnlyMemory<byte> payload,
        TimeSpan timeout,
        CancellationToken ct);
}
