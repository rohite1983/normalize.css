using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;

namespace MercedesDiag.Hal.Doip;

public sealed record DoipVehicleAnnouncement(
    IPEndPoint Source,
    string Vin,
    ushort LogicalAddress,
    byte[] Eid,
    byte[] Gid);

public static class DoipDiscovery
{
    public static async IAsyncEnumerable<DoipVehicleAnnouncement> DiscoverAsync(
        TimeSpan collectWindow,
        int port = DoipAdapter.DefaultDoipPort,
        [EnumeratorCancellation] CancellationToken ct = default)
    {
        using var udp = new UdpClient(AddressFamily.InterNetwork) { EnableBroadcast = true };
        udp.Client.Bind(new IPEndPoint(IPAddress.Any, 0));

        var request = DoipFrame.Create(
            DoipPayloadType.VehicleIdentificationRequest,
            DoipPayloads.VehicleIdentificationRequest()).ToArray();

        var broadcast = new IPEndPoint(IPAddress.Broadcast, port);
        await udp.SendAsync(request, request.Length, broadcast).ConfigureAwait(false);

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(collectWindow);

        while (!cts.IsCancellationRequested)
        {
            UdpReceiveResult result;
            try
            {
                result = await udp.ReceiveAsync(cts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                yield break;
            }

            if (!DoipFrame.TryReadHeader(result.Buffer, out _, out var type, out var length))
            {
                continue;
            }
            if (type != DoipPayloadType.VehicleAnnouncement) continue;
            if (result.Buffer.Length < DoipFrame.HeaderLength + length) continue;

            var payload = new ReadOnlySpan<byte>(
                result.Buffer, DoipFrame.HeaderLength, (int)length);
            if (!DoipPayloads.TryParseVehicleAnnouncement(
                    payload, out var vin, out var logical, out var eid, out var gid))
            {
                continue;
            }
            yield return new DoipVehicleAnnouncement(result.RemoteEndPoint, vin, logical, eid, gid);
        }
    }
}
