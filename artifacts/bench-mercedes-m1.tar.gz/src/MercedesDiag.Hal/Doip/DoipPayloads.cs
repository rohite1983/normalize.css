using System.Buffers.Binary;

namespace MercedesDiag.Hal.Doip;

public static class DoipPayloads
{
    public static byte[] VehicleIdentificationRequest() => Array.Empty<byte>();

    public static byte[] RoutingActivationRequest(ushort sourceAddress, byte activationType = 0x00)
    {
        var payload = new byte[11];
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(0, 2), sourceAddress);
        payload[2] = activationType;
        return payload;
    }

    public static byte[] DiagnosticMessage(ushort sourceAddress, ushort targetAddress, ReadOnlySpan<byte> userData)
    {
        var payload = new byte[4 + userData.Length];
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(0, 2), sourceAddress);
        BinaryPrimitives.WriteUInt16BigEndian(payload.AsSpan(2, 2), targetAddress);
        userData.CopyTo(payload.AsSpan(4));
        return payload;
    }

    public static bool TryParseRoutingActivationResponse(
        ReadOnlySpan<byte> payload,
        out ushort testerAddress,
        out ushort entityAddress,
        out DoipRoutingActivationResponseCode code)
    {
        testerAddress = 0;
        entityAddress = 0;
        code = default;
        if (payload.Length < 9) return false;

        testerAddress = BinaryPrimitives.ReadUInt16BigEndian(payload.Slice(0, 2));
        entityAddress = BinaryPrimitives.ReadUInt16BigEndian(payload.Slice(2, 2));
        code = (DoipRoutingActivationResponseCode)payload[4];
        return true;
    }

    public static bool TryParseDiagnosticMessage(
        ReadOnlySpan<byte> payload,
        out ushort sourceAddress,
        out ushort targetAddress,
        out ReadOnlyMemory<byte> userData)
    {
        sourceAddress = 0;
        targetAddress = 0;
        userData = default;
        if (payload.Length < 4) return false;

        sourceAddress = BinaryPrimitives.ReadUInt16BigEndian(payload.Slice(0, 2));
        targetAddress = BinaryPrimitives.ReadUInt16BigEndian(payload.Slice(2, 2));
        userData = payload.Slice(4).ToArray();
        return true;
    }

    public static bool TryParseVehicleAnnouncement(
        ReadOnlySpan<byte> payload,
        out string vin,
        out ushort logicalAddress,
        out byte[] eid,
        out byte[] gid)
    {
        vin = string.Empty;
        logicalAddress = 0;
        eid = Array.Empty<byte>();
        gid = Array.Empty<byte>();
        if (payload.Length < 32) return false;

        vin = System.Text.Encoding.ASCII.GetString(payload.Slice(0, 17)).TrimEnd('\0');
        logicalAddress = BinaryPrimitives.ReadUInt16BigEndian(payload.Slice(17, 2));
        eid = payload.Slice(19, 6).ToArray();
        gid = payload.Slice(25, 6).ToArray();
        return true;
    }
}
