using System.Buffers.Binary;

namespace MercedesDiag.Hal.Doip;

public readonly record struct DoipFrame(
    byte ProtocolVersion,
    DoipPayloadType PayloadType,
    ReadOnlyMemory<byte> Payload)
{
    public const byte ProtocolVersion2012 = 0x02;
    public const byte ProtocolVersion2019 = 0x03;
    public const int HeaderLength = 8;
    public const int MaxPayloadLength = 0x00FFFFFF;

    public static DoipFrame Create(DoipPayloadType type, ReadOnlyMemory<byte> payload, byte version = ProtocolVersion2012) =>
        new(version, type, payload);

    public int TotalLength => HeaderLength + Payload.Length;

    public void WriteTo(Span<byte> destination)
    {
        if (destination.Length < TotalLength)
        {
            throw new ArgumentException("Destination too small", nameof(destination));
        }
        destination[0] = ProtocolVersion;
        destination[1] = (byte)~ProtocolVersion;
        BinaryPrimitives.WriteUInt16BigEndian(destination.Slice(2, 2), (ushort)PayloadType);
        BinaryPrimitives.WriteUInt32BigEndian(destination.Slice(4, 4), (uint)Payload.Length);
        Payload.Span.CopyTo(destination.Slice(HeaderLength));
    }

    public byte[] ToArray()
    {
        var buffer = new byte[TotalLength];
        WriteTo(buffer);
        return buffer;
    }

    public static bool TryReadHeader(
        ReadOnlySpan<byte> buffer,
        out byte version,
        out DoipPayloadType type,
        out uint payloadLength)
    {
        version = 0;
        type = default;
        payloadLength = 0;
        if (buffer.Length < HeaderLength) return false;

        version = buffer[0];
        var inverse = buffer[1];
        if ((byte)~version != inverse) return false;

        type = (DoipPayloadType)BinaryPrimitives.ReadUInt16BigEndian(buffer.Slice(2, 2));
        payloadLength = BinaryPrimitives.ReadUInt32BigEndian(buffer.Slice(4, 4));
        return payloadLength <= MaxPayloadLength;
    }
}
