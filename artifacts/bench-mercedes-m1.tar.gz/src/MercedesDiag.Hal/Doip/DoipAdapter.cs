using System.Buffers;
using System.Buffers.Binary;
using System.Net;
using System.Net.Sockets;

namespace MercedesDiag.Hal.Doip;

public sealed class DoipAdapter : IDoipAdapter
{
    public const int DefaultDoipPort = 13400;
    public const ushort DefaultTesterAddress = 0x0E80;

    private readonly AdapterInfo _info;
    private readonly ushort _testerAddress;
    private TcpClient? _client;
    private NetworkStream? _stream;
    private bool _routingActivated;

    public DoipAdapter(IPEndPoint endpoint, ushort testerAddress = DefaultTesterAddress)
    {
        VehicleEndpoint = endpoint;
        _testerAddress = testerAddress;
        _info = new AdapterInfo(
            Id: $"doip://{endpoint}",
            DisplayName: $"DoIP {endpoint}",
            Kind: AdapterKind.DoipEnet);
    }

    public AdapterInfo Info => _info;
    public bool IsOpen => _client?.Connected ?? false;
    public IPEndPoint VehicleEndpoint { get; }
    public ushort TesterAddress => _testerAddress;

    public async ValueTask OpenAsync(CancellationToken ct)
    {
        if (IsOpen && _routingActivated) return;
        await CloseAsync(ct).ConfigureAwait(false);

        _client = new TcpClient { NoDelay = true };
        await _client.ConnectAsync(VehicleEndpoint, ct).ConfigureAwait(false);
        _stream = _client.GetStream();

        await ActivateRoutingAsync(ct).ConfigureAwait(false);
        _routingActivated = true;
    }

    public ValueTask CloseAsync(CancellationToken ct)
    {
        _routingActivated = false;
        _stream?.Dispose();
        _stream = null;
        _client?.Close();
        _client = null;
        return ValueTask.CompletedTask;
    }

    public async ValueTask<ReadOnlyMemory<byte>> SendReceiveAsync(
        ushort sourceAddress,
        ushort targetAddress,
        ReadOnlyMemory<byte> payload,
        TimeSpan timeout,
        CancellationToken ct)
    {
        if (!IsOpen || _stream is null)
        {
            throw new InvalidOperationException("DoIP adapter is not open.");
        }

        var source = sourceAddress == 0 ? _testerAddress : sourceAddress;
        var diagPayload = DoipPayloads.DiagnosticMessage(source, targetAddress, payload.Span);
        await SendFrameAsync(DoipPayloadType.DiagnosticMessage, diagPayload, ct).ConfigureAwait(false);

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeout);

        while (true)
        {
            var (type, body) = await ReadFrameAsync(cts.Token).ConfigureAwait(false);
            switch (type)
            {
                case DoipPayloadType.DiagnosticMessagePositiveAck:
                    continue;

                case DoipPayloadType.DiagnosticMessageNegativeAck:
                    var nackCode = body.Length >= 5 ? body.Span[4] : (byte)0xFF;
                    throw new DoipNegativeAcknowledgementException((DoipDiagnosticNegativeAckCode)nackCode);

                case DoipPayloadType.DiagnosticMessage:
                    if (!DoipPayloads.TryParseDiagnosticMessage(body.Span, out _, out _, out var userData))
                    {
                        throw new InvalidDataException("Malformed DoIP diagnostic message");
                    }
                    if (IsResponsePending(userData.Span))
                    {
                        continue;
                    }
                    return userData;

                case DoipPayloadType.AliveCheckRequest:
                    await SendAliveCheckResponseAsync(cts.Token).ConfigureAwait(false);
                    continue;

                default:
                    continue;
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        await CloseAsync(CancellationToken.None).ConfigureAwait(false);
    }

    private async Task ActivateRoutingAsync(CancellationToken ct)
    {
        var payload = DoipPayloads.RoutingActivationRequest(_testerAddress);
        await SendFrameAsync(DoipPayloadType.RoutingActivationRequest, payload, ct).ConfigureAwait(false);

        var (type, body) = await ReadFrameAsync(ct).ConfigureAwait(false);
        if (type != DoipPayloadType.RoutingActivationResponse)
        {
            throw new InvalidDataException($"Expected RoutingActivationResponse, got {type}.");
        }
        if (!DoipPayloads.TryParseRoutingActivationResponse(body.Span, out _, out _, out var code))
        {
            throw new InvalidDataException("Malformed routing activation response.");
        }
        if (code != DoipRoutingActivationResponseCode.Success &&
            code != DoipRoutingActivationResponseCode.SuccessConfirmationRequired)
        {
            throw new DoipRoutingActivationFailedException(code);
        }
    }

    private Task SendAliveCheckResponseAsync(CancellationToken ct)
    {
        var payload = new byte[2];
        BinaryPrimitives.WriteUInt16BigEndian(payload, _testerAddress);
        return SendFrameAsync(DoipPayloadType.AliveCheckResponse, payload, ct);
    }

    private async Task SendFrameAsync(DoipPayloadType type, ReadOnlyMemory<byte> payload, CancellationToken ct)
    {
        var frame = DoipFrame.Create(type, payload);
        var buffer = ArrayPool<byte>.Shared.Rent(frame.TotalLength);
        try
        {
            frame.WriteTo(buffer.AsSpan(0, frame.TotalLength));
            await _stream!.WriteAsync(buffer.AsMemory(0, frame.TotalLength), ct).ConfigureAwait(false);
            await _stream.FlushAsync(ct).ConfigureAwait(false);
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    private async Task<(DoipPayloadType Type, ReadOnlyMemory<byte> Body)> ReadFrameAsync(CancellationToken ct)
    {
        var header = new byte[DoipFrame.HeaderLength];
        await ReadExactlyAsync(header, ct).ConfigureAwait(false);

        if (!DoipFrame.TryReadHeader(header, out _, out var type, out var length))
        {
            throw new InvalidDataException("Invalid DoIP header.");
        }

        var body = new byte[length];
        if (length > 0)
        {
            await ReadExactlyAsync(body, ct).ConfigureAwait(false);
        }
        return (type, body);
    }

    private async Task ReadExactlyAsync(Memory<byte> buffer, CancellationToken ct)
    {
        var read = 0;
        while (read < buffer.Length)
        {
            var n = await _stream!.ReadAsync(buffer.Slice(read), ct).ConfigureAwait(false);
            if (n == 0) throw new EndOfStreamException("DoIP stream closed unexpectedly.");
            read += n;
        }
    }

    private static bool IsResponsePending(ReadOnlySpan<byte> udsResponse) =>
        udsResponse.Length >= 3 && udsResponse[0] == 0x7F && udsResponse[2] == 0x78;
}
