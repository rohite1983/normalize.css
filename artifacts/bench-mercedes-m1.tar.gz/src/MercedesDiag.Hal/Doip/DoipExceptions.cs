namespace MercedesDiag.Hal.Doip;

public sealed class DoipRoutingActivationFailedException : Exception
{
    public DoipRoutingActivationFailedException(DoipRoutingActivationResponseCode code)
        : base($"DoIP routing activation failed: 0x{(byte)code:X2} ({code})")
    {
        Code = code;
    }

    public DoipRoutingActivationResponseCode Code { get; }
}

public sealed class DoipNegativeAcknowledgementException : Exception
{
    public DoipNegativeAcknowledgementException(DoipDiagnosticNegativeAckCode code)
        : base($"DoIP diagnostic negative ack: 0x{(byte)code:X2} ({code})")
    {
        Code = code;
    }

    public DoipDiagnosticNegativeAckCode Code { get; }
}
