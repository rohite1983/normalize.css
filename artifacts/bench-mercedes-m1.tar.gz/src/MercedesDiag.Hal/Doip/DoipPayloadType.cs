namespace MercedesDiag.Hal.Doip;

public enum DoipPayloadType : ushort
{
    GenericNegativeAck = 0x0000,
    VehicleIdentificationRequest = 0x0001,
    VehicleIdentificationRequestWithEid = 0x0002,
    VehicleIdentificationRequestWithVin = 0x0003,
    VehicleAnnouncement = 0x0004,
    RoutingActivationRequest = 0x0005,
    RoutingActivationResponse = 0x0006,
    AliveCheckRequest = 0x0007,
    AliveCheckResponse = 0x0008,
    DoipEntityStatusRequest = 0x4001,
    DoipEntityStatusResponse = 0x4002,
    DiagnosticPowerModeRequest = 0x4003,
    DiagnosticPowerModeResponse = 0x4004,
    DiagnosticMessage = 0x8001,
    DiagnosticMessagePositiveAck = 0x8002,
    DiagnosticMessageNegativeAck = 0x8003,
}

public enum DoipRoutingActivationResponseCode : byte
{
    UnknownSourceAddress = 0x00,
    AllSocketsRegisteredAndActive = 0x01,
    DifferentSourceAddress = 0x02,
    SourceAlreadyRegistered = 0x03,
    MissingAuthentication = 0x04,
    RejectedConfirmation = 0x05,
    UnsupportedActivationType = 0x06,
    Success = 0x10,
    SuccessConfirmationRequired = 0x11,
}

public enum DoipDiagnosticNegativeAckCode : byte
{
    InvalidSourceAddress = 0x02,
    UnknownTargetAddress = 0x03,
    DiagnosticMessageTooLarge = 0x04,
    OutOfMemory = 0x05,
    TargetUnreachable = 0x06,
    UnknownNetwork = 0x07,
    TransportProtocolError = 0x08,
}
