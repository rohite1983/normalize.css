namespace MercedesDiag.Hal.Pcan;

public sealed class PcanAdapter : ICanAdapter
{
    public PcanAdapter(AdapterInfo info, int bitrateKbps)
    {
        Info = info;
        BitrateKbps = bitrateKbps;
    }

    public AdapterInfo Info { get; }
    public bool IsOpen { get; private set; }
    public int BitrateKbps { get; }

    public ValueTask OpenAsync(CancellationToken ct) =>
        throw new NotImplementedException("PCAN backend lands in M2.");

    public ValueTask CloseAsync(CancellationToken ct) =>
        throw new NotImplementedException("PCAN backend lands in M2.");

    public ValueTask SendAsync(CanFrame frame, CancellationToken ct) =>
        throw new NotImplementedException("PCAN backend lands in M2.");

    public IAsyncEnumerable<CanFrame> ReceiveAsync(CancellationToken ct) =>
        throw new NotImplementedException("PCAN backend lands in M2.");

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
