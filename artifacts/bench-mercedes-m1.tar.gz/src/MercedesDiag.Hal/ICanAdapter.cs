namespace MercedesDiag.Hal;

public readonly record struct CanFrame(uint Id, bool Extended, ReadOnlyMemory<byte> Data);

public interface ICanAdapter : IAdapter
{
    int BitrateKbps { get; }

    ValueTask SendAsync(CanFrame frame, CancellationToken ct);

    IAsyncEnumerable<CanFrame> ReceiveAsync(CancellationToken ct);
}
