namespace MercedesDiag.Coding.Aed;

public sealed class AedProvider : ICodingProvider
{
    private readonly string _rootDirectory;

    public AedProvider(string rootDirectory)
    {
        _rootDirectory = rootDirectory;
    }

    public string Name => "AED";

    public ValueTask<IReadOnlyList<string>> ListEcusAsync(CancellationToken ct) =>
        throw new NotImplementedException(".aed loader lands in M5.");

    public ValueTask<CodingTree> LoadAsync(string ecuName, CancellationToken ct) =>
        throw new NotImplementedException(".aed loader lands in M5.");
}
