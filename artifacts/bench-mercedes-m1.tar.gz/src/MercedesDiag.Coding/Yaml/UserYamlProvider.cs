namespace MercedesDiag.Coding.Yaml;

public sealed class UserYamlProvider : ICodingProvider
{
    private readonly string _rootDirectory;

    public UserYamlProvider(string rootDirectory)
    {
        _rootDirectory = rootDirectory;
    }

    public string Name => "User YAML";

    public ValueTask<IReadOnlyList<string>> ListEcusAsync(CancellationToken ct) =>
        throw new NotImplementedException("YAML coding loader lands in M3.");

    public ValueTask<CodingTree> LoadAsync(string ecuName, CancellationToken ct) =>
        throw new NotImplementedException("YAML coding loader lands in M3.");
}
