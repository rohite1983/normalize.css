namespace MercedesDiag.Coding;

public sealed record CodingOption(
    string Key,
    string DisplayName,
    ushort Did,
    int ByteOffset,
    int BitOffset,
    int BitLength,
    IReadOnlyDictionary<long, string> Values);

public sealed record CodingTree(
    string EcuName,
    IReadOnlyList<CodingOption> Options);

public interface ICodingProvider
{
    string Name { get; }

    ValueTask<IReadOnlyList<string>> ListEcusAsync(CancellationToken ct);

    ValueTask<CodingTree> LoadAsync(string ecuName, CancellationToken ct);
}
