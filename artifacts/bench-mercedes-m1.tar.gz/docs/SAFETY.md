# Safety & scope boundaries

This project is scoped as a **personal / workshop internal tool** for
Mercedes-Benz diagnostics and coding on cars the operator owns or
services with the owner's consent. It is not intended for
redistribution or commercial sale.

The following items are **permanently out of scope** and must not be
added, even when technically possible:

## 1. Anti-theft / VIN-lock write on head units

No feature that writes, resets, clears, or otherwise manipulates the
anti-theft lock on Audio20, COMAND, NTG, or similar head units. The
dominant real-world use is reactivating stolen units. If a PR
proposes this, close it.

## 2. Redistribution of Mercedes proprietary files

The repository must not contain SMR-D, CBF, .aed files, Xentry
databases, or any other Daimler proprietary coding artefacts. The
application reads such files only from the operator's local
filesystem, never bundled.

## 3. SCN online coding

SCN (Software Calibration Number) coding requires Mercedes backend
credentials and signed payloads. Do not implement it — it is both
technically infeasible without those credentials and, if circumvented,
legally problematic.

## Write safety (in scope, required)

Every coding write must:

1. Read and persist a backup of the current DID values for the
   affected ECU to a local JSON file **before** any write.
2. Refuse to proceed if the `CodingWriteSafety` tracker has not
   recorded a backup for that ECU in the current session.
3. Offer one-click restore from the backup.

`CodingWriteSafety` is the single source of truth. Do not add
code paths that bypass it.
