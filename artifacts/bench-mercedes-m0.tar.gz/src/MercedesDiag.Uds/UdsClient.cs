using MercedesDiag.Transport;

namespace MercedesDiag.Uds;

public sealed class UdsClient : IAsyncDisposable
{
    private readonly IDiagnosticChannel _channel;
    private readonly TimeSpan _defaultTimeout;

    public UdsClient(IDiagnosticChannel channel, TimeSpan? defaultTimeout = null)
    {
        _channel = channel;
        _defaultTimeout = defaultTimeout ?? TimeSpan.FromSeconds(2);
    }

    public async ValueTask<ReadOnlyMemory<byte>> RequestAsync(
        ReadOnlyMemory<byte> request,
        CancellationToken ct)
    {
        var response = await _channel.RequestAsync(request, _defaultTimeout, ct).ConfigureAwait(false);
        ThrowIfNegative(request.Span[0], response.Span);
        return response;
    }

    public async ValueTask<UdsSession> StartSessionAsync(UdsSession session, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.DiagnosticSessionControl, (byte)session };
        await RequestAsync(req, ct).ConfigureAwait(false);
        return session;
    }

    public async ValueTask<ReadOnlyMemory<byte>> ReadDataByIdentifierAsync(ushort did, CancellationToken ct)
    {
        var req = new byte[] { UdsServices.ReadDataByIdentifier, (byte)(did >> 8), (byte)(did & 0xFF) };
        var resp = await RequestAsync(req, ct).ConfigureAwait(false);
        return resp.Slice(3);
    }

    private static void ThrowIfNegative(byte requestService, ReadOnlySpan<byte> response)
    {
        if (response.Length >= 3 && response[0] == UdsServices.NegativeResponse && response[1] == requestService)
        {
            throw new UdsNegativeResponseException(requestService, (UdsNrc)response[2]);
        }
    }

    public ValueTask DisposeAsync() => _channel.DisposeAsync();
}
