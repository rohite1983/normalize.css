using System.Net;
using System.Net.Sockets;

namespace MercedesDiag.Hal.Doip;

public sealed class DoipAdapter : IDoipAdapter
{
    private readonly AdapterInfo _info;
    private TcpClient? _client;

    public DoipAdapter(IPEndPoint endpoint)
    {
        VehicleEndpoint = endpoint;
        _info = new AdapterInfo(
            Id: $"doip://{endpoint}",
            DisplayName: $"DoIP {endpoint}",
            Kind: AdapterKind.DoipEnet);
    }

    public AdapterInfo Info => _info;
    public bool IsOpen => _client?.Connected ?? false;
    public IPEndPoint VehicleEndpoint { get; }

    public async ValueTask OpenAsync(CancellationToken ct)
    {
        if (_client is { Connected: true }) return;
        _client = new TcpClient();
        await _client.ConnectAsync(VehicleEndpoint, ct).ConfigureAwait(false);
    }

    public ValueTask CloseAsync(CancellationToken ct)
    {
        _client?.Close();
        _client = null;
        return ValueTask.CompletedTask;
    }

    public ValueTask<ReadOnlyMemory<byte>> SendReceiveAsync(
        ushort sourceAddress,
        ushort targetAddress,
        ReadOnlyMemory<byte> payload,
        TimeSpan timeout,
        CancellationToken ct)
    {
        throw new NotImplementedException("DoIP framing lands in M1.");
    }

    public async ValueTask DisposeAsync()
    {
        await CloseAsync(CancellationToken.None).ConfigureAwait(false);
    }
}
