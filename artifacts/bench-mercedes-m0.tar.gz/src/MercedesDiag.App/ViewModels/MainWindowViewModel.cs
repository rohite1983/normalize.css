using CommunityToolkit.Mvvm.ComponentModel;

namespace MercedesDiag.App.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    [ObservableProperty]
    private string _status = "Not connected";

    [ObservableProperty]
    private string _greeting = "Hello, ECU";

    public string Version => typeof(MainWindowViewModel).Assembly.GetName().Version?.ToString() ?? "0.0.0";
}
