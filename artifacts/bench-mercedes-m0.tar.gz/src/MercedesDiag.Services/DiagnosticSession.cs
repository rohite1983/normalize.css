using MercedesDiag.Transport;
using MercedesDiag.Uds;
using Microsoft.Extensions.Logging;

namespace MercedesDiag.Services;

public sealed class DiagnosticSession : IAsyncDisposable
{
    private readonly ILogger<DiagnosticSession> _logger;
    private readonly UdsClient _uds;

    public DiagnosticSession(IDiagnosticChannel channel, ILogger<DiagnosticSession> logger)
    {
        _logger = logger;
        _uds = new UdsClient(channel);
    }

    public UdsClient Uds => _uds;

    public async ValueTask<string?> ReadVinAsync(CancellationToken ct)
    {
        const ushort VinDid = 0xF190;
        try
        {
            var bytes = await _uds.ReadDataByIdentifierAsync(VinDid, ct).ConfigureAwait(false);
            return System.Text.Encoding.ASCII.GetString(bytes.Span).TrimEnd('\0', ' ');
        }
        catch (NotImplementedException)
        {
            _logger.LogInformation("VIN read not yet implemented at M0");
            return null;
        }
    }

    public ValueTask DisposeAsync() => _uds.DisposeAsync();
}
